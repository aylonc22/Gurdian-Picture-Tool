const ImageMagick = require('imagemagick');
const compress_images = require("compress-images")
const sharp = require('sharp');

const  INPUT_path_to_your_images = "01DE002.png";
const OUTPUT_path = "temp/";


function compress()
{
   compress_images(INPUT_path_to_your_images, OUTPUT_path, { compress_force: false, statistic: true, autoupdate: true }, false,
                { jpg: { engine: "mozjpeg", command: ["-quality", "60"] } },
                { png: { engine: "pngquant", command: ["--quality=20-50", "-o"] } },
                { svg: { engine: "svgo", command: "--multipass" } },
                { gif: { engine: "gifsicle", command: ["--colors", "64", "--use-col=web"] } },
  function (error, completed, statistic) {
    console.log("-------------");
    console.log(error);
    console.log(completed);
    console.log(statistic);
    console.log("-------------");
  }
);
}

function convert(input,output,bmName,quality,r,g,b)
{
     sharp(input).flatten({ background: { r: r, g: g, b: b } })
    .jpeg({
      quality: quality,
      chromaSubsampling: '4:4:4'
    })
    .toFile(output + bmName +" light.jpg");
}
//compress();
convert(INPUT_path_to_your_images,OUTPUT_path,"lol",100,255,255,255);